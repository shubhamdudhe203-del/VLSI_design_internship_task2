`timescale 1ns/1ps
module tb_basic_gates;

    reg A, B;
    wire AND_out, OR_out, NOT_out, NAND_out, NOR_out, XOR_out;

    // Instantiate the design
    basic_gates uut (
        .A(A),
        .B(B),
        .AND_out(AND_out),
        .OR_out(OR_out),
        .NOT_out(NOT_out),
        .NAND_out(NAND_out),
        .NOR_out(NOR_out),
        .XOR_out(XOR_out)
    );

    initial begin
        // Enable waveform dump for EPWave
        $dumpfile("basic_gates.vcd");   
        $dumpvars(0, tb_basic_gates);   

        // Monitor values in console
        $monitor("Time=%0t | A=%b B=%b | AND=%b OR=%b NOT=%b NAND=%b NOR=%b XOR=%b",
                  $time, A, B, AND_out, OR_out, NOT_out, NAND_out, NOR_out, XOR_out);

        // Test all input combinations
        A = 0; B = 0; #10;
        A = 0; B = 1; #10;
        A = 1; B = 0; #10;
        A = 1; B = 1; #10;

        $finish;
    end

endmodule