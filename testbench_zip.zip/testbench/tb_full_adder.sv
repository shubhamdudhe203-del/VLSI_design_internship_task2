// Code your testbench here
// or browse Examples
`timescale 1ns/1ps

module tb_full_adder;

    reg a, b, cin;       // Inputs
    wire sum, cout;      // Outputs

    // Instantiate the DUT (Device Under Test)
    full_adder uut (
        .a(a),
        .b(b),
        .cin(cin),
        .sum(sum),
        .cout(cout)
    );

    initial begin
        // Dump waveforms for EPWave
        $dumpfile("full_adder.vcd");
        $dumpvars(0, tb_full_adder);

        // Apply test cases
        a=0; b=0; cin=0; #10;
        a=0; b=0; cin=1; #10;
        a=0; b=1; cin=0; #10;
        a=0; b=1; cin=1; #10;
        a=1; b=0; cin=0; #10;
        a=1; b=0; cin=1; #10;
        a=1; b=1; cin=0; #10;
        a=1; b=1; cin=1; #10;

        // End simulation
        $finish;
    end

    // Monitor values in console
    initial begin
        $monitor("Time=%0t | a=%b b=%b cin=%b -> sum=%b cout=%b",
                  $time, a, b, cin, sum, cout);
    end

endmodule
