
`timescale 1ns/1ps

module tb_half_adder;

    reg A, B;
    wire Sum, Carry;

    // Instantiate DUT
    half_adder uut (
        .A(A),
        .B(B),
        .Sum(Sum),
        .Carry(Carry)
    );

    initial begin
        // Dump signals into VCD file
        $dumpfile("half_adder.vcd");   // creates VCD file
        $dumpvars(0, tb_half_adder);

        // Apply test cases
        A=0; B=0; #10;
        A=0; B=1; #10;
        A=1; B=0; #10;
        A=1; B=1; #10;

        $finish;
    end
endmodule
