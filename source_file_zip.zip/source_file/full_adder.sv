// Code your design here
// Full Adder Design
module full_adder (
    input wire a,       // First input
    input wire b,       // Second input
    input wire cin,     // Carry input
    output wire sum,    // Sum output
    output wire cout    // Carry output
);

    // Logic equations
    assign sum  = a ^ b ^ cin;                  // XOR for sum
    assign cout = (a & b) | (b & cin) | (a & cin); // Carry logic

endmodule
