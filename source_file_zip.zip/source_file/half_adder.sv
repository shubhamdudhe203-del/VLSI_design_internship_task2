// Half Adder Design
module half_adder (
    input A,
    input B,
    output Sum,
    output Carry
);

    assign Sum   = A ^ B;  // XOR for sum
    assign Carry = A & B;  // AND for carry

endmodule
