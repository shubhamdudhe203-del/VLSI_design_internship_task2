// Code your design here
// Six Basic Logic Gates in One Module
module basic_gates(
    input wire A,       // Input A
    input wire B,       // Input B
    output wire AND_out,
    output wire OR_out,
    output wire NOT_out,
    output wire NAND_out,
    output wire NOR_out,
    output wire XOR_out
);

    assign AND_out  = A & B;     // AND Gate
    assign OR_out   = A | B;     // OR Gate
    assign NOT_out  = ~A;        // NOT Gate (on A)
    assign NAND_out = ~(A & B);  // NAND Gate
    assign NOR_out  = ~(A | B);  // NOR Gate
    assign XOR_out  = A ^ B;     // XOR Gate

endmodule
